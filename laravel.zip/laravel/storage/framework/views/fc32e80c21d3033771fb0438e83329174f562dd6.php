<!DOCTYPE html>
<html lang="es">
<meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <?php /* Scripts */ ?>
    <?php echo Html::script('assets/js/jquery-2.2.3.js'); ?>

    <?php echo Html::script('assets/js/bootstrap.js'); ?>

    <?php echo Html::script('assets/js/bootstrap-datetimepicker.min.js'); ?>

    <?php echo Html::script('assets/js/script.js'); ?>

    
    <?php /* Styles */ ?>
    <?php echo Html::style('assets/css/principal.css'); ?>

    <?php echo Html::style('assets/css/bootstrap.css'); ?>

    <?php echo Html::style('assets/css/font-awesome.css'); ?>

    <?php echo Html::style('assets/css/w3.css'); ?>

    <?php echo Html::style('assets/css/bootstrap-datetimepicker.min.css'); ?>

    <header>
    	<div class="row">
    			<div class="col-md-9 col-sm-8 col-xs-6">
   					<h1 id="logoIndice"><?php echo e(HTML::linkAction('ControladorPrincipal@index', 'Clinic', "",array("id"=>"logo"))); ?> </h1>
   				</div>
    </header>
			<div class='container'>
        		<form method="POST" class="form-horizontal" role="form">
       
        		<?php echo e(csrf_field()); ?>

           		 		
           		 		<div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0">
            	       	 	<h3> Registro de paciente</h3>
            	       </div>
            	        
            	       		<div class="form-group">
            		  			<?php echo Form::label("Nombre","", array("class"=>"control-label col-sm-2")); ?>

            		  		<div class="col-sm-8">
            		  		<?php echo Form::input("text", "nombre", "", array("class"=>"campoRegistro form-control")); ?>

            		  		<div class="text-danger"><?php echo e($errors->first('nombre')); ?></div>
            		  		</div></div>
  						
   						    <div class="form-group">
            				<?php echo Form::label("apellidos","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-8">
            				<?php echo Form::input("text", "apellidos","", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>  
            				
            				<div class="form-group">
							<?php echo Form::label("Nacimiento","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<?php echo Form::input("date", "nacimiento", "", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>  
            				
            				<div class="form-group">
							<?php echo Form::label("DNI","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<?php echo Form::input("text", "dni","", array("class"=>"campoRegistro form-control")); ?>

            				<div class="text-danger"><?php echo e($errors->first('dni')); ?></div>
            				</div></div>   	
            				
            				<div class="form-group">
            				<?php echo Form::label("seguro","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-8">
            				<select name="compañia" class="form-control">
            					<option value='-1'> Selecciona una compañia aseguradora: </option>
    							<?php $c = DB::table("compañiaseguros")->get();
								foreach($c as $co){ 
									?>
								<option value="<?php echo $co->id_compañia ?>"> <?php echo $co->nombre; ?> </option>
								<?php 
									}
								?>
  							</select>
							</div>
            				</div>
            				
							<div class="form-group">	            			
            				<?php echo Form::label("email","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-8">
            				<?php echo Form::input("email", "email","", array("class"=>"campoRegistro form-control")); ?>

            				<div class="text-danger"><?php echo e($errors->first('email')); ?></div>
            				</div></div>
						
							<div class="form-group">						
							<?php echo Form::label("contraseña","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<?php echo Form::input("password", "password","", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>

							<div class="form-group">
							<?php echo Form::label("Repita la contraseña","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<?php echo Form::input("password", "password_confirmation","", array("class"=>"campoRegistro form-control")); ?>

            				<div class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></div>
            				</div></div>

							<div class="form-group">
							<?php echo Form::label("direccion","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<?php echo Form::input("text", "direccion","", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>

							<div class="form-group">
							<?php echo Form::label("codigopostal","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<?php echo Form::input("text", "cp","", array("class"=>"campoRegistro form-control")); ?>

            				<div class="text-danger"><?php echo e($errors->first('codigopostal')); ?></div></div></div>

							<div class="form-group">
							<?php echo Form::label("Población","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<?php echo Form::input("text", "poblacion","", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>
							
							<div class="form-group">
							<?php echo Form::label("Provincia","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<?php echo Form::input("text", "provincia","", array("class"=>"campoRegistro form-control")); ?>

							</div></div>
	
							<div class="form-group">
            				<?php echo Form::label("Teléfono","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-8">
            				<?php echo Form::input("text", "telefono","", array("class"=>"campoRegistro form-control")); ?>

							<div class="text-danger"><?php echo e($errors->first('telefono')); ?></div>
							</div></div>

							<div class="form-group">
								<div class="col-sm-offset-5 col-sm-8 col-md-offset-5 col-md-8 col-xs-offset-4 col-xs-8">
            						<?php echo Form::submit("Registrarse", array("class"=>"btnRegistro btn btn-primary")); ?>

            					</div>
            				</div>
           		</div>
          
        	</form>
