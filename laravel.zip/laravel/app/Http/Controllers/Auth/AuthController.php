<?php

namespace App\Http\Controllers\Auth;

use Mail;
use Auth;
use App\User;
use Session;
use Redirect;
use Validator;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;

class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    protected $redirectTo = '/';

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware($this->guestMiddleware(), ['except' => 'logout']);
        $this->middleware('guest', ['except' => ['logout', 'getLogout']]);
    }
	
	/**
     * Get the login username to be used by the controller.
	 * Función que autentifica usuarios a traves del email
     * @return string
     */
    public function loginUsername()
    {
        return property_exists($this, 'username') ? $this->username : 'email';
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|min:6|confirmed',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);
    }

	//Creamos la accion postLogin para autenticar a los usuarios
	public function postLogin(Request $request){
		
		if(Auth::attempt(
			[
				'email' => $request->email,
				'password' =>$request->password
			]	
					)){
			
		
						
			return redirect()->intended($this->redirectPath());
		
		
		}else{
			$rules = [
            	'email' => 'required|email',
            	'password' => 'required',
        			];
		
        	$messages = [
            	'email.required' => 'El campo email es requerido',
            	'email.email' => 'El formato de email es incorrecto',
            	'password.required' => 'El campo password es requerido',
        		];
			
			$validator = Validator::make($request->all(), $rules, $messages);

        	return redirect('/')
        			->withErrors($validator)
        			->withInput()
        			->with('message', 'Error al iniciar sesión');
		}
	}

	//Creamos la accion getLogout para cerrar la sesión del usuario logeado
	public function getLogout(){
		
		Auth::logout();
		return redirect('/');
	}
	

}
