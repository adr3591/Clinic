<?php /* Heredamos de la plantilla principal */ ?>


<?php $__env->startSection('content'); ?>
		<div class="container">
		<div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0">	
			<h3> Cita online </h3>
		</div>
		<?php
		$usuario = Auth::user()->email; //Obtenemos el usuario que esta actualmente atenticado
		$p = DB::table("pacientes")->where('email', $usuario)->first(); //Generamos la consulta para obtener dicho paciente
		$c = DB::table("compañiaseguros")->where('id_compañia', $p->id_compañia)->first();?>

		
		<form method="POST" class="form-horizontal" role="form">
			<?php /* Protección CSRF 'Cross-site request forgeries'*/ ?>
			<?php echo e(csrf_field()); ?>

		
		<input type="hidden" name="_token" value="<?php echo e($p->id_paciente); ?>" id="id_paciente">
		
		<div class="form-group">
          <?php echo Form::label("Nombre","", array("class"=>"control-label col-sm-2")); ?>

        <div class="col-sm-8">
		<input type="text" name="nombre" class="campoRegistro form-control" value="<?php echo $p->nombre;?>" readonly>
        </div></div>
		
		 <div class="form-group">
          <?php echo Form::label("apellidos","", array("class"=>"control-label col-sm-2")); ?>

         <div class="col-sm-8">
         <input type="text" name="apellidos" class="campoRegistro form-control" value="<?php echo $p->apellidos;?>" readonly>
         </div></div> 
		
		<div class="form-group">
		<?php echo Form::label("DNI","", array("class"=>"control-label col-sm-2")); ?>

		<div class="col-sm-8">
        <input type="text" name="dni" class="campoRegistro form-control" value="<?php echo $p->dni;?>" readonly>
        </div></div> 
		
		<div class="form-group">	            			
        <?php echo Form::label("email","", array("class"=>"control-label col-sm-2")); ?>

        <div class="col-sm-8">
        <input type="text" name="email" class="campoRegistro form-control" value="<?php echo $p->email;?>" readonly>
        </div></div>
			
		<div class="form-group">
         <?php echo Form::label("seguro","", array("class"=>"control-label col-sm-2")); ?>

        <div class="col-sm-8">
        <input type="text" name="seguroCita" class="campoRegistro form-control" value="<?php echo $c->nombre;?>" readonly>
		</div></div>

		<div class="form-group">
           <?php echo Form::label("especialidad","", array("class"=>"control-label col-sm-2")); ?>

        <div class="col-sm-8">
			<select  name="especialidadCita" class="form-control" id="selectEsp" value="">
				<option value='0'> </option>
    			<?php $e = DB::table("especialidades")->get();
					foreach($e as $es){ 
				?>
			<option value="<?php echo $es->id_especialidad ?>"> <?php echo $es->nombre; ?> </option>
			<?php } ?>
			</select>
			<div class="text-danger"><?php echo e($errors->first('especialidadCita')); ?></div>
        </div></div>	
		
		<div class="form-group" id="divTramoHorario">
			<?php echo Form::label("Tramo Horario","", array("class"=>"control-label col-sm-2")); ?>

		<div class="col-sm-8">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token">
			<select name="tramoHorario" class="form-control" id="tramoHorario" value="">
			<option value=''> </option>
			<option value='mañana'>Mañana</option>
			<option value='tarde'>Tarde</option></select>
			<div class="text-danger"><?php echo e($errors->first('tramoHorario')); ?></div>
        </div></div> 
		
		<div class="form-group" id="divCitas">
			
			<div class='row' id='pideCita'>
				
				<div class='col-sm-8 col-sm-offset-5  col-md-8 col-md-offset-5 col-xs-8 col-xs-offset-4 ' id='loading'>
					<i class="fa fa-spinner fa-pulse fa-3x fa-fw"></i>
					<span class="sr-only">Loading...</span>
				</div>
				
				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token2">
				
			</div>
			
			</div>
		
		<div class="form-group">
			<?php echo Form::label("Motivo","", array("class"=>"control-label col-sm-2")); ?>

		<div class="col-sm-8">
			<textarea name="motivoCita" class="form-control" rows="3" id='motivoCita' ></textarea>
		</div> </div>
		
		
		<div class="botonSubmit form-group">
			<div class="col-sm-offset-5 col-sm-8 col-md-offset-5 col-md-8 col-xs-offset-4 col-xs-8">
       			 <?php echo Form::button("Solicitar cita", array("id"=>"btnSolicitaCita","class"=>"btn btn-primary")); ?>

        	</div>
        </div>
		
	</form>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>