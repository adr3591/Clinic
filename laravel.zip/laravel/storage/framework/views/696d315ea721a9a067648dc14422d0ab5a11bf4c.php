<!-- Heredamos de la plantilla principal -->


<?php $__env->startSection('content'); ?>


Hola soy una especialidad


<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>