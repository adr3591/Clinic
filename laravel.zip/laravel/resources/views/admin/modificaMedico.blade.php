{{-- Heredamos de la plantilla principal --}}
@extends('layouts.principal')

@section('content')

<div id='datosRegistro' class='container'>
        		<form method="POST" class="form-horizontal" role="form">
       
        		{{csrf_field()}}
           		 		
           		 		<?php $m = DB::table("medicos")->where("id_medico",$id)->first(); ;?>
						
						<div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0">
            	        	<h3> Modificar Médico </h3>
            	       </div>
            	       		<div class="form-group">
            		  		{!! Form::label("nombre","", array("class"=>"control-label col-sm-2")) !!}
            		  		<div class="col-sm-8">
							<input type="text" name="nombre" class="form-control" value="<?php echo $m->nombre;?>">            		  		
							<div class="text-danger">{{$errors->first('nombre')}}</div>
            		  		</div></div>
  						
   						    <div class="form-group">
            				{!! Form::label("apellidos","", array("class"=>"control-label col-sm-2")) !!}
            				<div class="col-sm-8">
            				<input type="text" name="apellidos" class="form-control" value="<?php echo $m->apellidos;?>">  
            				</div></div>  

            				<div class="form-group">
							{!! Form::label("DNI","", array("class"=>"control-label col-sm-2")) !!}
							<div class="col-sm-8">
            				<input type="text" name="dni" class="form-control" value="<?php echo $m->dni;?>">  
            				<div class="text-danger">{{$errors->first('dni')}}</div>
            				</div></div>   	

							<div class="form-group">
            				{!! Form::label("especialidad","", array("class"=>"control-label col-sm-2")) !!}
            				<div class="col-sm-8">
            				<select name="especialidad" class="form-control">
            					<?php $em = DB::table("especialidades")->where('id_especialidad', $m->id_especialidad)->first();?>
            					<option value="<?php echo $m->id_especialidad; ?>"> <?php echo $em->nombre;?> </option>
    							<?php $e = DB::table("especialidades")->get();?>
								@foreach($e as $esp){ 
									@if($esp->nombre != $m->nombre)
										<option value="<?php echo $esp->id_especialidad ?>"> <?php echo $esp->nombre; ?> </option>
									@endif
								@endforeach
								
  							</select>
							</div>
            				</div>
            				
            				<div class="form-group">	            			
            				{!! Form::label("email","", array("class"=>"control-label col-sm-2")) !!}
            				<div class="col-sm-8">
            				<input type="text" name="email" class="form-control" value="<?php echo $m->email;?>"> 
            				<div class="text-danger">{{$errors->first('email')}}</div>
            				</div></div>
            				
            				<div class="form-group">
							{!! Form::label("direccion","", array("class"=>"control-label col-sm-2")) !!}
							<div class="col-sm-8">
            				<input type="text" name="direccion" class="form-control" value="<?php echo $m->direccion;?>"> 
            				</div></div>

							<div class="form-group">
							{!! Form::label("codigopostal","", array("class"=>"control-label col-sm-2")) !!}
							<div class="col-sm-8">
            				<input type="text" name="codigopostal" class="form-control" value="<?php echo $m->codigopostal;?>"> 
            				<div class="text-danger">{{$errors->first('codigopostal')}}</div></div></div>

							<div class="form-group">
							{!! Form::label("Población","", array("class"=>"control-label col-sm-2")) !!}
							<div class="col-sm-8">
            				<input type="text" name="poblacion" class="form-control" value="<?php echo $m->poblacion;?>"> 
            				</div></div>
							
							<div class="form-group">
							{!! Form::label("Provincia","", array("class"=>"control-label col-sm-2")) !!}
							<div class="col-sm-8">
            				<input type="text" name="provincia" class="form-control" value="<?php echo $m->provincia;?>"> 
							</div></div>
	
							<div class="form-group">
            				{!! Form::label("Teléfono","", array("class"=>"control-label col-sm-2")) !!}
            				<div class="col-sm-8">
            				<input type="text" name="telefono" class="form-control" value="<?php echo $m->telefono;?>"> 
							<div class="text-danger">{{$errors->first('telefono')}}</div>
							</div></div>

							<div class="form-group">
							{!! Form::label("Nº Colegiado","", array("class"=>"control-label col-sm-2")) !!}
							<div class="col-sm-8">
            				<input type="text" name="colegiado" class="form-control" value="<?php echo $m->n_colegiado;?>"> 
							</div></div>
							
							<div class="form-group">
								<div class="col-sm-offset-5 col-sm-8 col-md-offset-5 col-md-8 col-xs-offset-4 col-xs-8">
            				{!! Form::submit("Modificar", array("class"=>"btnRegistro btn btn-primary")) !!}
            				</div></div>
           		</div>
          
        	</form>

@stop