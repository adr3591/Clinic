<!-- Heredamos de la plantilla principal -->


<?php $__env->startSection('content'); ?>

    <section>	
    	
<div class="container">
  <br>
  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Lista ordenada -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
      <li data-target="#myCarousel" data-slide-to="3"></li>
    </ol>

    <!-- Contenedor imagenes -->
    <div class="carousel-inner" role="listbox">
      <div class="item active">
        <img src="../public/assets/imagenes/slideShow/photo_1.jpg" alt="Chania" width="460" height="345">
      </div>

      <div class="item">
        <img src="../public/assets/imagenes/slideShow/photo_2.jpg" alt="Chania" width="460" height="345">
      </div>
    
      <div class="item">
        <img src="../public/assets/imagenes/slideShow/photo_3.jpg" alt="Flower" width="460" height="345">
      </div>

      <div class="item">
        <img src="../public/assets/imagenes/slideShow/photo_4.jpg" alt="Flower" width="460" height="345">
      </div>
    </div>

    <!-- Controles derecha e izquierda -->
    <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>
    	
    	<div class="row">
				<h3 class="col-xs-12"> Servicios </h3>
			</div>
        <div id="divEspecialidades" class="container">
				
				<?php
				$espe = DB::table('especialidades')->get();
				$total = count($espe);
				$cont=0;
				while($cont<$total){
					$esp=$espe[$cont]; ?>
        	    <div class="row">
	            	<div class="col-md-6  portfolio-item">
						<div class="panel panel-primary">
							<div class="panel-heading">
								<h3 class="panel-title"> <?php echo $esp->nombre;?></h3>
							</div>
							<div class="panel-body">
								<div class="imagenCaja col-md-6  col-sm-6 col-xs-12  portfolio-item">
									<img src='<?php echo $esp->imagen_caja; ?>' >
								</div>
								<div class="detalleCaja col-md-6  col-sm-6 col-xs-12 portfolio-item"><?php echo $esp->detalle; ?>
									<?php echo Html::linkAction('ControladorEspecialidad@especialidad','Más Información',array($esp->nombre_corto),
																												  array("class"=>"botonInfo")); ?>

								</div>	
							</div>				
				    	</div>
				     </div>
				     
				    <?php
				    if ($cont<$total-1){
				    $esp=$espe[$cont+1];
					?>
				    <div class="col-md-6 portfolio-item">
						<div class="panel panel-primary">
							<div class="panel-heading">
								<h3 class="panel-title"> <?php echo $esp->nombre;?>  </h3>
							</div>
							<div class="panel-body">
								<div class="imagenCaja col-md-6  col-sm-6 col-xs-12  portfolio-item">
									<img src='<?php echo $esp->imagen_caja; ?>' >
								</div>
								  <div class="detalleCaja col-md-6  col-sm-6 col-xs-12 portfolio-item"><?php echo $esp->detalle; ?>
									<?php echo Html::linkAction('ControladorEspecialidad@especialidad','Más Información',array($esp->nombre_corto),
																												 array("class"=>"botonInfo")); ?>

								</div>
							</div>				
				    	</div>
				    </div>
			     </div>
				<?php } $cont+=2;} ?>	
			
       
        </div>
        
     </section>
     
 	    <footer>
 	    	<div class="row">
 	    		<div class="col-md-4 col-md-offset-5"> Adrián Haro Luna ™  </div>
 	    	 </div>
 	    </footer>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>