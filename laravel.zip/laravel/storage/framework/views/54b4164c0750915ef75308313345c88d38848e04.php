<!DOCTYPE html>
<html lang="es">
<meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Scripts -->
    <?php echo Html::script('../public/assets/js/jquery-2.2.3.js'); ?>

    <?php echo Html::script('../public/assets/js/bootstrap.js'); ?>

    <?php echo Html::script('../public/assets/js/script.js'); ?>

    
    <!-- Styles -->
    <?php echo Html::style('../public/assets/css/principal.css'); ?>

    <?php echo Html::style('../public/assets/css/bootstrap.css'); ?>

    <?php echo Html::style('../public/assets/css/font-awesome.css'); ?>


<div id='contenedorPrincipal'>
    
    <header>
   			
   			<?php echo Form::open(array('url'=>'', 'method'=>'POST')); ?>

   			
   			<?php echo Form::submit("Acceder", array("class"=>"btn btn-default")); ?>

   
   
            <?php echo Form::input("button", "login", "Login",array("class"=>"btnLogin btn btn-default",
                                                              "id"=>"bton")); ?>

                                                                                                          
            <?php echo Form::input("hidden", "contraseña", "", array("class"=>"campoOculto form-control",
                                                                "size"=>"10",
                                                                "placeholder"=>"Contraseña")); ?>

                                                             
            <?php echo Form::input("hidden", "usuario","", array("class"=>"campoOculto form-control",
                                                            "size"=>"10",
                                                            "placeholder"=>"Usuario")); ?>

            
            <?php echo Form::close(); ?> 
       		
			<?php echo e(HTML::linkAction('ControladorRegistro@index','Registro')); ?>

      		
        <h1> Clinic </h1>
        
    </header>
    
    
    <nav> </nav>
    
	<?php echo $__env->yieldContent('content'); ?>

</div>