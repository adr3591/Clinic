<!DOCTYPE html>
<html lang="es">
<meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    
    				{{-- Scripts --}}
    {!! Html::script('assets/js/jquery-2.2.3.js') !!}
    {!! Html::script('assets/js/bootstrap.js') !!}
    {!! Html::script('assets/js/bootstrap-datetimepicker.min.js') !!}
    {!! Html::script('assets/js/script.js') !!}
    {!! Html::script('assets/js/admin.js') !!}
    
    				{{-- Styles --}}
    {!! Html::style('assets/css/principal.css') !!}
    {!! Html::style('assets/css/bootstrap.css') !!}
    {!! Html::style('assets/css/font-awesome.css') !!}
    {!! Html::style('assets/css/w3.css') !!}
    {!! Html::style('assets/css/bootstrap-datetimepicker.min.css') !!}
    

    <div id='contenedorPrincipal'>
    	
    <header>
    	
    		<div class="row">
    			<div class="col-md-9 col-sm-8 col-xs-6">
   					<h1 id="logoIndice">{{ HTML::linkAction('ControladorPrincipal@index', 'Clinic', "",array("id"=>"logo"))}} </h1>
   				</div>
   			
    		<div class="col-md-3 col-sm-3 col-xs-6">    	
    		<form method="POST" class="form-horizontal" role="form" id="formLogin">
			{{-- Protección CSRF 'Cross-site request forgeries'--}}
			{{csrf_field()}}
				{{-- Si dicho usuario logeado es paciente se habilitara el botón para pedir cita--}}
			@if(Auth::check())
			
				<?php $paciente = DB::table("pacientes")->select("nombre","apellidos")->where('email', Auth::user()->email)->first();?>
					<label class="labelEmailUsuario"> <?php echo $paciente->nombre; echo $paciente->apellidos;         ?> </label> <br>
				
					
					
					@if((Auth::user()->tipo_role) == 0)
						{{ HTML::linkAction('ControladorCitas@pideCita', 'Cita online', array(),array("class"=>"botonCita btn btn-success"))}} <br>
   						{{ HTML::linkAction('ControladorCitas@historial', 'Historial paciente', array(),array("class"=>"botonHistorial btn btn-default"))}} <br>

   					@endif
   				
   					
   				{{-- Si dicho usuario logeado es administrador se habilitara el botón correspondiente a la administracion de la página--}}
   				
   					@if((Auth::user()->tipo_role) == 1)
   						{{ HTML::linkAction('ControladorAdmin@index', 'Administración', array(), array("class"=>"botonAdmin btn btn-warning"))}} <br>
   					@endif
   					
   				   
   				{{ HTML::linkAction('Auth\AuthController@getLogout','Cerrar sesión', array(),array("class"=>"botonCerrarSesion btn btn-danger"))}}
   				
   			@else
   				<div style="margin-bottom: 5px" class="input-group">
   				 <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
   				{!! Form::text("email", "", array("size"=>"5","placeholder"=>"Email","class"=>"form-control")) !!}
   				 </div> 
            	 @if ($errors->has('email'))
                       <span class="help-block">
                       		<strong>{{ $errors->first('email') }}</strong>
                       </span>
           		 @endif
           		 
           		 
           		
           		  <div style="margin-bottom: 5px" class="input-group">
                  	<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>                                             
   					{!! Form::password("password",  array("size"=>"10","placeholder"=>"Contraseña", "class"=>"form-control"))!!}
   				  </div>
   				    
              	@if ($errors->has('password'))
                        <span class="help-block">
                              <strong>{{ $errors->first('password') }}</strong>
                        </span>
            	@endif  
            	          
            	
            	                              			
   				{!! Form::submit("Acceder", array("class"=>"btn btn-default")) !!}	
   				{{ HTML::linkAction('ControladorRegistro@index','Registro', array(),array("class"=>"botonRegistro btn btn-primary")) }}

				@endif
			</form>
   			
   			</div>	
   			</div>
    </header>

    
	
@yield('content')
</div>