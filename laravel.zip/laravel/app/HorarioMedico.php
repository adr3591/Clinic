<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class HorarioMedico extends Authenticatable
{

	//Variables 
	protected $table = "horario_medico";
	
	/*
	 * En el caso en que nuestra clave primaria se llamara 'id' no hace falta declararla como varible.
	 * Como no es nuestro caso debemos declararla.
	 */
	 
	protected $primaryKey = "id_horario";
	
	protected $fillable = ['lunes','martes','miercoles','jueves','viernes'];					   
	
	
	/* Relaciones */
	
	//Tabla medicos
	
	public function medicos(){
		
		return $this->belongsTo('App\Medicos');
	}
	
	

}

