<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Citas extends Authenticatable
{

	//Variables 
	
	
	
	protected $table = "citas";
	
	/*
	 * En el caso en que nuestra clave primaria se llamara 'id' no hace falta declararla como varible.
	 * Como no es nuestro caso debemos declararla.
	 */
	
	protected $primaryKey = "id_cita";
	
	protected $fillable = ['fecha','hora','motivo'];
	
	
	
	/** Relaciones */
	
	//Relacion especialidades-citas (uno a muchos)
	
	public function especialidades(){
		
		return $this->hasMany('App\Especialidades','id_especialidad');
		
	}
	
		
}
	