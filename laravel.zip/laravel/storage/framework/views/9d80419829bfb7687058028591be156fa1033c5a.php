<!-- Heredamos de la plantilla principal -->


<?php $__env->startSection('content'); ?>
	<div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0">
		<h3> Panel administración personal paciente</h3>
	</div>
	
	<div class="divBotones">
		<a href="<?php echo e(URL::to('/admin/pacientes')); ?>"><i class="fa fa-2x fa-refresh"></i></a>
	</div>
	<p> Total de registros: <?php echo e($pacientes->total()); ?> </p>
	<p> Página <?php echo e($pacientes->currentPage()); ?> de <?php echo e($pacientes->lastPage()); ?></p>
	<table class="table table-hover">
		<thead>
			<tr>
			<td><strong>Nombre</strong></td>
			<td><strong>DNI</strong></td>
			<td><strong>Email</strong></td>
			<td><strong>Compañia seguros</strong></td>
			 </tr>
		</thead> 
		<tbody>
			<?php foreach($pacientes as $paciente): ?>
				<tr class=<?php echo e($paciente->id_paciente); ?>> 
				<td> <?php echo e($paciente->nombre); ?> <?php echo e($paciente->apellidos); ?> </td>
				<td> <?php echo e($paciente->dni); ?> </td>
				<td> <?php echo e($paciente->email); ?></td>
				<?php 
				 $c = DB::table("compañiaseguros")->select('nombre')->where('id_compañia',$paciente->id_compañia)->first();
				?>
				<td><?php foreach($c as $s){ echo $c->nombre; } ?></td> </tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php echo $pacientes->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>