{{-- Heredamos de la plantilla principal --}}
@extends('layouts.principal')

@section('content')

<div id='datosRegistro' class='container'>
        		<form method="POST" class="form-horizontal" role="form">
       
        		{{csrf_field()}}
           		 		<div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0">
            	        	<h3> Registro médico </h3>
            	        </div>
            	        
            	       		<div class="form-group">
            		  		{!! Form::label("nombre","", array("class"=>"control-label col-sm-2")) !!}
            		  		<div class="col-sm-8">
            		  		{!! Form::input("text", "nombre", "", array("class"=>"campoRegistro form-control")) !!}
            		  		<div class="text-danger">{{$errors->first('nombre')}}</div>
            		  		</div></div>
  						
   						    <div class="form-group">
            				{!! Form::label("apellidos","", array("class"=>"control-label col-sm-2")) !!}
            				<div class="col-sm-8">
            				{!! Form::input("text", "apellidos","", array("class"=>"campoRegistro form-control")) !!}
            				</div></div>  

            				<div class="form-group">
							{!! Form::label("DNI","", array("class"=>"control-label col-sm-2")) !!}
							<div class="col-sm-8">
            				{!! Form::input("text", "dni","", array("class"=>"campoRegistro form-control")) !!}
            				<div class="text-danger">{{$errors->first('dni')}}</div>
            				</div></div>   	

							<div class="form-group">
            				{!! Form::label("especialidad","", array("class"=>"control-label col-sm-2")) !!}
            				<div class="col-sm-8">
            				<select name="especialidad" class="form-control">
            					<option value="0"> </option>
    							<?php $e = DB::table("especialidades")->get();
								foreach($e as $esp){ 
									?>
								<option value="<?php echo $esp->id_especialidad ?>"> <?php echo $esp->nombre; ?> </option>
								<?php 
									}
								?>
  							</select>
							</div>
            				</div>
            				
            				<div class="form-group">	            			
            				{!! Form::label("email","", array("class"=>"control-label col-sm-2")) !!}
            				<div class="col-sm-8">
            				{!! Form::input("email", "email","", array("class"=>"campoRegistro form-control")) !!}
            				<div class="text-danger">{{$errors->first('email')}}</div>
            				</div></div>
            				
            				<div class="form-group">
							{!! Form::label("direccion","", array("class"=>"control-label col-sm-2")) !!}
							<div class="col-sm-8">
            				{!! Form::input("text", "direccion","", array("class"=>"campoRegistro form-control")) !!}
            				</div></div>

							<div class="form-group">
							{!! Form::label("codigopostal","", array("class"=>"control-label col-sm-2")) !!}
							<div class="col-sm-8">
            				{!! Form::input("text", "codigopostal","", array("class"=>"campoRegistro form-control")) !!}
            				<div class="text-danger">{{$errors->first('codigopostal')}}</div></div></div>

							<div class="form-group">
							{!! Form::label("Población","", array("class"=>"control-label col-sm-2")) !!}
							<div class="col-sm-8">
            				{!! Form::input("text", "poblacion","", array("class"=>"campoRegistro form-control")) !!}
            				</div></div>
							
							<div class="form-group">
							{!! Form::label("Provincia","", array("class"=>"control-label col-sm-2")) !!}
							<div class="col-sm-8">
            				{!! Form::input("text", "provincia","", array("class"=>"campoRegistro form-control")) !!}
							</div></div>
	
							<div class="form-group">
            				{!! Form::label("Teléfono","", array("class"=>"control-label col-sm-2")) !!}
            				<div class="col-sm-8">
            				{!! Form::input("text", "telefono","", array("class"=>"campoRegistro form-control")) !!}
							<div class="text-danger">{{$errors->first('telefono')}}</div>
							</div></div>

							<div class="form-group">
							{!! Form::label("Nº Colegiado","", array("class"=>"control-label col-sm-2")) !!}
							<div class="col-sm-8">
            				{!! Form::input("text", "colegiado","", array("class"=>"campoRegistro form-control")) !!}
							</div></div>
							
							<div class="form-group">
								<div class="col-sm-offset-5 col-sm-8 col-md-offset-5 col-md-8 col-xs-offset-4 col-xs-8">
            				{!! Form::submit("Registrar", array("class"=>"btnRegistro btn btn-primary")) !!}
            				</div></div>
           		</div>
          
        	</form>

@stop