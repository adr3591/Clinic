<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
| 
| 
| 
|
|
|
|
*/

Route::get('/nuevoMedico', function() 
{ 
  return View::make('admin.nuevoMedico') ;
}); 

Route::get('/admin/especialidades', 'ControladorAdmin@especialidades');

Route::get('/admin/medicos', 'ControladorAdmin@medicos');

Route::get('/admin/pacientes', 'ControladorAdmin@pacientes');

Route::get('/admin/compañias', 'ControladorAdmin@compañias');

Route::get('/admin/citas', 'ControladorAdmin@citas');

//Ruta hacia la accion principal del panel de administración
Route::get('/admin', 'ControladorAdmin@index');

//Ruta hacia la petición ajax fecha
Route::post('peticionFecha', 'ControladorCitas@solicitarCitas');

//Ruta hacia la petición ajax medicos
Route::post('peticionMedico', 'ControladorCitas@devuelveMedico');

//Ruta hacia el controlador Registro
Route::get('/registro', 'ControladorRegistro@index');

//Ruta hacia las distintas especialidades
Route::get('/especialidades/{nombre_corto}', 'ControladorEspecialidad@especialidad');

//Ruta que manda al controlador para el registro de pacientes
Route::get('/citaonline', 'ControladorCitas@pideCita');

Route::post('guardarCita', 'ControladorCitas@guardaCita');

//Ruta que manda al controlador para el registro de pacientes
Route::get('/admin', 'ControladorAdmin@index');

Route::get('/historial','ControladorCitas@historial');

//Ruta que manda al controlador para la modificación del médico seleccionado pasado por get
Route::get("/modificaMedico/{id}", "ControladorAdmin@modificaMedico");

//Ruta que envia por post el resultado del medico a modificar
Route::post('/modificaMedico/{id}', 'ControladorAdmin@modificarMedico');

//Borrar medico
Route::post('admin/borrarMedico', 'ControladorAdmin@borrarMedico');

//Nuevo medico
Route::post("/nuevoMedico","ControladorAdmin@nuevoMedico");

//Ruta que manda al controlador para el registro de pacientes
Route::post('/registro', 'ControladorRegistro@registroPaciente');

Route::get('/logout', 'Auth\AuthController@getLogout');

//Ruta que manda al controlador para que valide el usuario y su correspondiente contraseña 
Route::post('/', 'Auth\AuthController@postLogin');

//index
Route::get('/', 'ControladorPrincipal@index');

//Errores
Route::get('log', '\Rap2hpoutre\LaravelLogViewer\LogViewerController@index');
