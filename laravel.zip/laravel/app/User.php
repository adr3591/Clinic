<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
	 
	 protected $table = 'users';
	
    protected $fillable = [
        'email', 'password'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token'
    ];
	
	
	/**
	 * Función que recibe la contraseña por parametro 
	 * y la encripta a través del método propio bcrypt de laravel
	 */
	public function setPasswordAttribute($password){
		$this->attributes['password'] = bcrypt($password);
	}
}
