<?php

namespace App;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Pacientes extends Authenticatable
{

	//Variables 
	protected $table = "pacientes";
	
	/*
	 * En el caso en que nuestra clave primaria se llamara 'id' no hace falta declararla como varible.
	 * Como no es nuestro caso debemos declararla.
	 */
	
	protected $primaryKey = "id_paciente";
	

	protected $fillable = ['dni','nombre','apellidos','contraseña','rcontraseña','fecha_nacimiento','direccion',
						   'codigopostal','poblacion','provincia','email','telefono'];
	
	/* Relaciones */
	
	//Tabla usuarios (uno a uno)
	
	public function usuario(){
		
		return $this->belongsTo('App\Usuarios');
	}
	
	
	//Tabla medicos (muchos a muchos)
	
	public function medicos(){
		
		return $this->belongsToMany('App\Medicos','id_medico');
		
	}
	
	
	//Tabla compañias de seguros (uno a muchos)
	
	public function compañiaseguros(){
		
		return $this->hasMany('App\Compañiaseguros','id_compañia');
	
	}
	

}