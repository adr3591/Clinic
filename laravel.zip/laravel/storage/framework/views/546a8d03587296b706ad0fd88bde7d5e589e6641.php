<!DOCTYPE html>
<html lang="es">
<meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <?php /* Scripts */ ?>
    <?php echo Html::script('assets/js/jquery-2.2.3.js'); ?>

    <?php echo Html::script('assets/js/bootstrap.js'); ?>

    <?php echo Html::script('assets/js/bootstrap-datetimepicker.min.js'); ?>

    <?php echo Html::script('assets/js/script.js'); ?>

    
    <?php /* Styles */ ?>
    <?php echo Html::style('assets/css/principal.css'); ?>

    <?php echo Html::style('assets/css/bootstrap.css'); ?>

    <?php echo Html::style('assets/css/font-awesome.css'); ?>

    <?php echo Html::style('assets/css/w3.css'); ?>

    <?php echo Html::style('assets/css/bootstrap-datetimepicker.min.css'); ?>

    <header>
    	<div class="row">
    			<div class="col-md-9 col-sm-8 col-xs-6">
   					<h1 id="logoIndice"><?php echo e(HTML::linkAction('ControladorPrincipal@index', 'Clinic', "",array("id"=>"logo"))); ?> </h1>
   				</div>
    </header>
<?php
$espe = DB::table("especialidades")->where('nombre_corto',$especialidad)->first();

?>
	<div class="container">
		<div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0">
			<h3> Servicios </h3>
		</div>
		<?php $e = DB::table("especialidades")->get(); ?>
		
			<div class="row">
			<div class="col-md-3 col-sm-3 col-xs-5">
			<div class="list-group">
			
				<?php foreach($e as $es): ?>
					<?php echo Html::linkAction('ControladorEspecialidad@especialidad',$es->nombre, array($es->nombre_corto),
				     																     array('class'=>'list-group-item')); ?>

				<?php endforeach; ?>

			</div>
			</div>
		
			<div class="col-md-8 col-sm-9 col-xs-7">
			
				<div class="imagenEsp">
					<img class='img-responsive' src='<?php echo $espe->imagen; ?>' >
				</div>
		</div>
				<div class="col-md-9 col-sm-9 col-xs-7">
				<div class="nombreEsp">
					<?php 
				  		echo $espe->nombre;
					?>
				</div>
				<div class="descripEsp">
					<?php						
						echo $espe->informacion;
	
						//Concatenamos los servicios adicionales y los añadimos a una lista desordenada
						//si hay valores en el campo adicional de la base de datos					
						$adi = $espe->adicional;						
						if($adi==""){}	
						else{				
							$ad = explode("|", $adi);
							?>  <ul> <?php
							foreach($ad as $a){ ?>
								<li> <?php echo $a; ?> </li>	
							<?php
							}?></ul><?php
						}				
					?>					
				</div>
			</div>
			
		</div>
		</div>

