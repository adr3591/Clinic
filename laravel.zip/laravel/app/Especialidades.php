<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Especialidades extends Authenticatable
{

	//Variables
	
	 
	protected $table = "especialidades";
	
	
	/*
	 * En el caso en que nuestra clave primaria se llamara 'id' no hace falta declararla como varible.
	 * Como no es nuestro caso debemos declararla.
	 */
	 
	protected $primaryKey = "id_especialidad";
	
	
	protected $fillable = ['nombre'];
	
	
	public $timestamps = false;
	
	/** Relaciones */
	
	/* Relacion especialidades-medicos (uno a muchos)
	 * Un médico tiene una sola especialidad mientras que una 
	 * especialidad pueden tenerla uno o varios médicos */
	
	public function medicos(){
		
		return $this->belongsTo('App\Medicos');
	}
	
	//Relación especialidades-citas (uno a muchos)
	
	public function citas(){
		
		return $this->belongsTo('App\Citas');
		
	}
	
		
}
	