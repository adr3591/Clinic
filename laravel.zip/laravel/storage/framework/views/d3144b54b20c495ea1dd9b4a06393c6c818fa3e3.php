<?php /* Heredamos de la plantilla principal */ ?>


<?php $__env->startSection('content'); ?>
	
	<script> 
		function borrar(tr){
			
			var id = tr.attr('id');
			var token = $('#token').val();

			$.ajax({
				//Url para la peticion
        		url: 'borrarMedico',
        		//datos a enviar
        		data:{'id' : id},
        		//Cabecera
        		headers: {'X-CSRF-TOKEN':token},
        		//peticion por post
        		type: 'POST',
        		//json
        		dataType: 'json',
        		//Si la peticion es correcta, la respuesta es pasada como argumento a la funcion
        		success: function (json){
        			console.log(json);
					tr.remove();
					$("<div class='alert alert-warning alert-dismissable'>"+
  							"<button type='button' class='close' data-dismiss='alert'>&times;</button>"+
  							"<strong>Borrado</strong> Es muy importante que leas este mensaje de alerta.</div>").insertAfter("h3");
        	
				},
				//Si la peticion falla
				error: function(jqXHR, status, error){
        			
        			console.log(jqXHR);
        			console.log(status);
        			console.log(error);
        			
        			
        			$("<div class='alert alert-warning alert-dismissable'>"+
  							"<button type='button' class='close' data-dismiss='alert'>&times;</button>"+
  							"<strong>¡Cuidado!</strong> Es muy importante que leas este mensaje de alerta.</div>").insertAfter("h3");
        	
        		}
        		
      		});
		
		
		}
	</script>
	
	<div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0">
		<h3> Panel administración personal médico</h3>
	</div>
	
	<div class="divBotones">
		<a target='_blank' href="<?php echo e(URL::to('/nuevoMedico')); ?>"><i class="fa fa-2x fa-user-plus" aria-hidden="true"></i></a>
		<a href="<?php echo e(URL::to('/admin/medicos')); ?>"><i class="fa fa-2x fa-refresh"></i></a>
	</div>
	
	<p> Total de registros: <?php echo e($medicos->total()); ?> </p>
	<p> Página <?php echo e($medicos->currentPage()); ?> de <?php echo e($medicos->lastPage()); ?></p>
	
	<table class="table table-hover">
		<thead>
			<tr>
				<td><strong>Nombre</strong></td>
				<td><strong>DNI</strong></td>
				<td><strong>Email</strong></td>
				<td><strong>Especialidad</strong></td>
				<td><strong>Modificar</strong></td>
				<td><strong>Borrar</strong></td>
			</tr>
		</thead>
		<tbody>
			
			<?php foreach($medicos as $medico): ?>
				
				<tr id=<?php echo e($medico->id_medico); ?>> 
				<td> <?php echo e($medico->nombre); ?> <?php echo e($medico->apellidos); ?></td>
				<td> <?php echo e($medico->dni); ?> </td>
				<td> <?php echo e($medico->email); ?> </td>
				<?php 
				 $e = DB::table("especialidades")->select('nombre')->where('id_especialidad',$medico->id_especialidad)->first();
				?>
				<td><?php foreach($e as $a){ echo $e->nombre; } ?></td>	
				<td><a target='_blank' href="<?php echo e(URL::to('/modificaMedico', array('id'=> $medico->id_medico ))); ?>"><i class='modificarMedico fa fa-pencil' aria-hidden='true'></i></a></td>
				
				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" id="token">
				<td><i class="borrarMedico fa fa-trash-o" aria-hidden="true" onclick="borrar($(this).parents('tr'))"></i> </td> </tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	
	<div class="col-lg-12 col-lg-offset-5 col-md-12 col-md-offset-5 col-sm-12 col-sm-offset-5 col-sm-12 col-xs-offset-5">
		<?php echo $medicos->render(); ?>

	</div>
	
	<div id="myModal" class="modal fade">
  					<div class="modal-dialog" role="document">
    				<div class="modal-content">
      				<div class="modal-header">
       			<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          			<span aria-hidden="true">&times;</span>
       			</button>
       		    	<h4 class="modal-title">Borrado Médico</h4>
      			</div>
      			<div class="modal-body">
     			   <p>¿Está seguro de borrar al médico? </p>
      			</div>
      			<div class="modal-footer">
       			 <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        			<button type="button" class="btn btn-primary">Borrar</button>
     			 </div>
   				 </div>
  				</div>
				</div>
	
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>