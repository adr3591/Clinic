<!-- Heredamos de la plantilla principal -->
@extends('layouts.principal')

@section('content')

	<div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0">
		<h3> Panel administración citas</h3>
	</div>
	
	
	<div class="col-md-2 col-md-offset-11 col-sm-12 col-sm-offset-0 col-xs-12 col-xs-offset-0">
		<a href="{{ URL::to('/admin/citas') }}"><i class="fa fa-2x fa-refresh"></i></a>
	</div>
	
	<div class="col-md-6 col-md-offset-0">
		<p> Total de registros: {{ $citas->total() }} </p>
		<p> Página {{$citas->currentPage() }} de {{ $citas->lastPage() }}</p>
	</div>
	
	<table class="table table-hover">
		<thead>
			<tr>
				<td><strong>Paciente</strong></td>
				<td><strong>Médico</strong></td>
				<td><strong>Especialidad</strong></td>
				<td><strong>Fecha</strong></td>
				<td><strong>Hora</strong></td>
			</tr>
		</thead>
		<tbody>

		@foreach($citas as $cita)
		
			<tr class={{ $cita->id_cita }}>
				<?php 
				
				
				$d = DB::selectOne("select distinct pacientes.nombre, pacientes.apellidos, citas.id_paciente from citas 
								inner join pacientes on pacientes.id_paciente = citas.id_paciente
							where citas.fecha = '$cita->fecha' and citas.hora = '$cita->hora' LIMIT 1;");
							
				$paciente = DB::table("pacientes")->select("id_paciente")->where('email', Auth::user()->email)->first();
				if($d->id_paciente == $paciente->id_paciente){			
							
				?>
							
				<td><?php echo $d->nombre; echo $d->apellidos; ?></td>
				<?php $m = DB::table("medicos")->select('nombre','apellidos')->where('id_medico',$cita->id_medico)->first();?>
				<td><?php  echo $m->nombre; echo $m->apellidos;  ?></td>
				<?php $e = DB::table("especialidades")->select('nombre')->where('id_especialidad',$cita->id_especialidad)->first();?>
				<td><?php foreach($e as $i){ echo $e->nombre;} ?></td>
				<?php $date = date_create($cita->fecha); ?>
				<td><?php echo date_format($date, "d-m-Y") ?></td>
				<td> {{ $cita->hora }} </td>
		    </tr>
		    <?php } ?>
			@endforeach
		</tbody>
		
	</table>
	
	{!! $citas->render() !!}
	
@stop