<?php 

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;

class ControladorEspecialidad extends Controller{

	
	public function especialidad($nombre_corto){

		return view('especialidades.especialidad', array("especialidad"=>$nombre_corto));

	}
	
}