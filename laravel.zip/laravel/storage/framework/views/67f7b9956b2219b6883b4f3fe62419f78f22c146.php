<!-- Heredamos de la plantilla principal -->


<?php $__env->startSection('content'); ?>

	<h3> Panel administración compañias aseguradoras</h3>

	<div class="divBotones">
		<a href="<?php echo e(URL::to('/')); ?>"><i class="fa fa-2x fa-plus-circle"></i></a>
		<a href="<?php echo e(URL::to('/admin/')); ?>"><i class="fa fa-2x fa-refresh"></i></a>
	</div>

	<p> Total de registros: <?php echo e($compañias->total()); ?> </p>
	<p> Página <?php echo e($compañias->currentPage()); ?> de <?php echo e($compañias->lastPage()); ?></p>
	<table class="table table-hover">
		<thead>
			<tr>
				<td><strong>Nombre</strong></td>
			</tr>
		</thead>
		<tbody>
			
			<?php foreach($compañias as $compañia): ?>
				
				<tr class=<?php echo e($compañia->id_compañia); ?>> 
				<td> <?php echo e($compañia->nombre); ?></td>

			<?php endforeach; ?>
		</tbody>
	</table>
	
	<?php echo $compañias->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>