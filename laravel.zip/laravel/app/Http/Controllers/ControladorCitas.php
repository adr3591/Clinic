<?php 

namespace App\Http\Controllers;


use DB;
use Auth;
use App\Citas;
use App\Medicos;
use Redirect;
use Validator;
use App\Http\Requests;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Http\Controllers\Controller;

class ControladorCitas extends Controller{

	public function __construct(){
		
		$this->middleware('auth');
		
	}


	public function pideCita(){
		
		return view("citas.cita");
		
	}
	
	public function historial(){
		
		$citas = Citas::paginate(10);
		
		return view("citas.historial", compact('citas'));
	}
	
	/*Acción que devuelve los diferentes médicos por cada especialidad*/
	public function devuelveMedico(Request $request){
		
		//Si la petición es mediante ajax
		if($request->ajax()){
			
			//Consulta que devuelve los 'id_medico' por cada especialidad
			$m = DB::table("medicos")->select('id_medico','nombre', 'apellidos')->where('id_especialidad',$request->input('id'))->get();
			
			return json_encode($m);
		}	
	}
	
	//Accion que solicita citas 
	public function solicitarCitas(Request $request){

		date_default_timezone_set('Europe/Madrid');
		
		$dias_semana = array("domingo", "lunes", "martes", "miercoles", "jueves", "viernes", "sabado");
		
		//Obtenemos la fecha y hora actual
		$fechaActual = date("Y-m-d"); $horaActual = date("H:i:s");
		$dia_semana = $dias_semana[date("w")];
		
		
		$reglas = [
					'especialidadCita' => 'required',
					'tramoHorario'=>'required'
				  ];
		
		$mensajes = [
					  'especialidadCita' => 'La especialidad es requerida',
					  'tramoHorario.required' => 'La hora es requerida',
					];
						
		$validator = Validator::make($request->all(), $reglas, $mensajes);
		
		if ($validator->fails()){
            	return redirect("/citaonline")
            	->withErrors($validator)
            	->withInput();
		
		}else{
		
		//Consulta que devuelve los 'id_medico' por cada especialidad
		$medicos = DB::table("medicos")->select('id_medico','nombre','apellidos')->where('id_especialidad',$request->input('especialidadCita'))->get();
	
		$citas = [];
		
		$tramo = $request->input('tramoHorario');

		foreach ($medicos as $medico) {
			$citas[$medico->id_medico] = DB::table("citas")->select('hora','fecha')->where("id_medico", $medico->id_medico)
									   ->where("fecha", '>',$fechaActual)->get();
									   
			$horarios[$medico->id_medico] = DB::table("horario_medico")->where('id_medico', $medico->id_medico)->get();
		}
		
		$horasDisponibles = array();
		$horasDisponibles["mañana"]=["09:00:00","10:00:00","11:00:00","12:00:00","13:00:00"];
		$horasDisponibles["tarde"]=["16:00:00","17:00:00","18:00:00","19:00:00","20:00:00"];
		$temp = array();
		
		
		$i=0;
		$fecha=date("Y-m-d");
		while($i<6){
			$nuevafecha = strtotime ( '+1 day' , strtotime ( $fecha ) ) ;
			$nuevafecha = date ( 'Y-m-d' , $nuevafecha );
			$s=$dias_semana[date_format (date_create($nuevafecha), "w")];
			$fecha=$nuevafecha;
			
			if ($s!="domingo"){
				$info=array();
				$hay_horas=false;
				foreach ($horarios as $h => $valor) {
					
					//$id_m=$h;
					$id_m=$valor[0]->id_medico;
					
					if ($tramo==$valor[0]->$s){
																								
						$horasCita = DB::table("citas")->select('hora')->where("id_medico", $id_m)
										   ->where("fecha", $nuevafecha)->get();
						
						$nombreMedico = DB::table("medicos")->select('nombre','apellidos')->where("id_medico",$id_m)->get();
						
						
						$citas=array();
						foreach ($horasCita as $cita => $value) {
							array_push($citas, $value->hora);
						}
						
						foreach($nombreMedico as $medico =>$value){
							$nombre = $value->nombre.$value->apellidos;
						}
						
						
						$horas=array_diff($horasDisponibles[$tramo], $citas);
						if (!empty($horas)) {
							$hay_horas=true;
							array_push($info, array("id"=>$id_m, "nombre"=>$nombre, "horas"=>$horas));
						}

					}	
				}
				
				if ($hay_horas) {
					$temp[$s]["fecha"]=$nuevafecha;
					$temp[$s]["medicos"]=$info;
					$i++;
				}
			} 
		}

		return json_encode($temp);

		}
	}
	
	
	/**
	 * Acción que guarda la cita
	 */
	 
	 public function guardaCita(Request $request){
	 	
		$cita = new Citas;
		$cita->id_paciente = $request->input("id_paciente");
		$cita->id_medico = $request->input("id_medico");
		$cita->id_especialidad = $request->input("id_especialidad");
		$cita->fecha = $request->input("fecha");
		$cita->hora = $request->input("hora");
		$cita->motivo = $request->input("motivo");
		
		$cita->save();
		
		
		return json_encode("<div class='alert alert-success'> </div>");
		
		
	 }
	
	
	
	
	
	
	
}