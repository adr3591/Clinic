<meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">

	<script src="../../public/js/jquery-2.2.3.js"></script> 
    <link rel="stylesheet" href="../../public/css/principal.css">

<div id='cabecera'>
<h1> Clinic </h1>
</div>

<div id='cuerpo'>

</div>