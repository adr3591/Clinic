<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Medicos extends Authenticatable
{

	//Variables 
	protected $table = "medicos";
	
	/*
	 * En el caso en que nuestra clave primaria se llamara 'id' no hace falta declararla como varible.
	 * Como no es nuestro caso debemos declararla.
	 */
	 
	protected $primaryKey = "id_medico";
	
	
	protected $fillable = ['dni','nombre','apellidos','direccion',
						   'codigopostal','poblacion','provincia',
						   'email','telefono','n_colegiado'];
						   
	
	/* Relaciones */
	
	//Tabla pacientes muchos a muchos
	
	public function pacientes(){
		
		return $this->belongsToMany('App\Pacientes','id_paciente');
		
	}
	
	
	//Tabla especialidad
	
	public function especialidades(){
		
		return $this->hasMany('App\Especialidades', 'id_medico');
		
	}
	
	//Tabla horario_medico
	public function horarioMedico(){
		
		return $this->hasMany('App\HorarioMedico', 'id_medico');
		
	}
	
	
		
}
	