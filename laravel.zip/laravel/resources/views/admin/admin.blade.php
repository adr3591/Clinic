<!-- Heredamos de la plantilla principal -->
@extends('layouts.principal')

@section('content')
	<div class='container'>
		
		<div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0 ">
			<h3> Panel de Administración</h3>
		</div>
	
		
		<div class="col-sm-12">
			<div class="list-group">
		
				{!! Html::linkAction('ControladorAdmin@citas', 'Citas', '', array('target'=>'_blank','class'=>'list-group-item')) !!} </li>
		    	{!! Html::linkAction('ControladorAdmin@medicos', 'Médicos', '', array('target'=>'_blank','class'=>'list-group-item')) !!} </li>
				{!! Html::linkAction('ControladorAdmin@pacientes', 'Pacientes','', array('target'=>'_blank','class'=>'list-group-item')) !!} </li>		
		
			</div>
		</div>
	</div>
























@stop