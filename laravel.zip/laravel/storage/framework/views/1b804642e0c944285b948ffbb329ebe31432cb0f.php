<?php /* Heredamos de la plantilla principal */ ?>


<?php $__env->startSection('content'); ?>

<div id='datosRegistro' class='container'>
        		<form method="POST" class="form-horizontal" role="form">
       
        		<?php echo e(csrf_field()); ?>

           		 		
           		 		<?php $m = DB::table("medicos")->where("id_medico",$id)->first(); ;?>
						
						<div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0">
            	        	<h3> Modificar Médico </h3>
            	       </div>
            	       		<div class="form-group">
            		  		<?php echo Form::label("nombre","", array("class"=>"control-label col-sm-2")); ?>

            		  		<div class="col-sm-8">
							<input type="text" name="nombre" class="form-control" value="<?php echo $m->nombre;?>">            		  		
							<div class="text-danger"><?php echo e($errors->first('nombre')); ?></div>
            		  		</div></div>
  						
   						    <div class="form-group">
            				<?php echo Form::label("apellidos","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-8">
            				<input type="text" name="apellidos" class="form-control" value="<?php echo $m->apellidos;?>">  
            				</div></div>  

            				<div class="form-group">
							<?php echo Form::label("DNI","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<input type="text" name="dni" class="form-control" value="<?php echo $m->dni;?>">  
            				<div class="text-danger"><?php echo e($errors->first('dni')); ?></div>
            				</div></div>   	

							<div class="form-group">
            				<?php echo Form::label("especialidad","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-8">
            				<select name="especialidad" class="form-control">
            					<?php $em = DB::table("especialidades")->where('id_especialidad', $m->id_especialidad)->first();?>
            					<option value="<?php echo $m->id_especialidad; ?>"> <?php echo $em->nombre;?> </option>
    							<?php $e = DB::table("especialidades")->get();?>
								<?php foreach($e as $esp): ?>{ 
									<?php if($esp->nombre != $m->nombre): ?>
										<option value="<?php echo $esp->id_especialidad ?>"> <?php echo $esp->nombre; ?> </option>
									<?php endif; ?>
								<?php endforeach; ?>
								
  							</select>
							</div>
            				</div>
            				
            				<div class="form-group">	            			
            				<?php echo Form::label("email","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-8">
            				<input type="text" name="email" class="form-control" value="<?php echo $m->email;?>"> 
            				<div class="text-danger"><?php echo e($errors->first('email')); ?></div>
            				</div></div>
            				
            				<div class="form-group">
							<?php echo Form::label("direccion","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<input type="text" name="direccion" class="form-control" value="<?php echo $m->direccion;?>"> 
            				</div></div>

							<div class="form-group">
							<?php echo Form::label("codigopostal","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<input type="text" name="codigopostal" class="form-control" value="<?php echo $m->codigopostal;?>"> 
            				<div class="text-danger"><?php echo e($errors->first('codigopostal')); ?></div></div></div>

							<div class="form-group">
							<?php echo Form::label("Población","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<input type="text" name="poblacion" class="form-control" value="<?php echo $m->poblacion;?>"> 
            				</div></div>
							
							<div class="form-group">
							<?php echo Form::label("Provincia","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<input type="text" name="provincia" class="form-control" value="<?php echo $m->provincia;?>"> 
							</div></div>
	
							<div class="form-group">
            				<?php echo Form::label("Teléfono","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-8">
            				<input type="text" name="telefono" class="form-control" value="<?php echo $m->telefono;?>"> 
							<div class="text-danger"><?php echo e($errors->first('telefono')); ?></div>
							</div></div>

							<div class="form-group">
							<?php echo Form::label("Nº Colegiado","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<input type="text" name="colegiado" class="form-control" value="<?php echo $m->n_colegiado;?>"> 
							</div></div>
							
							<div class="form-group">
								<div class="col-sm-offset-5 col-sm-8 col-md-offset-5 col-md-8 col-xs-offset-4 col-xs-8">
            				<?php echo Form::submit("Modificar", array("class"=>"btnRegistro btn btn-primary")); ?>

            				</div></div>
           		</div>
          
        	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>