<!DOCTYPE html>
<html lang="es">
<meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Scripts -->
    <?php echo Html::script('/public/assets/js/jquery-2.2.3.js'); ?>

    <?php echo Html::script('/public/assets/js/bootstrap.js'); ?>

    <?php echo Html::script('/public/assets/js/script.js'); ?>

    
    <!-- Styles -->
    <?php echo Html::style('public/assets/css/principal.css'); ?>

    <?php echo Html::style('public/assets/css/bootstrap.css'); ?>


<div id='contenedorPrincipal'>
    
    <header>
   
            <?php echo Form::input("button", "login", "Login",array("class"=>"btn btn-default",
                                                              "id"=>"bton")); ?>

                                                                                                          
            <?php echo Form::input("hidden", "contraseña", "", array("class"=>"campoOculto form-control",
                                                                "size"=>"10",
                                                                "placeholder"=>"Contraseña")); ?>

                                                             
            <?php echo Form::input("hidden", "usuario","", array("class"=>"campoOculto form-control",
                                                            "size"=>"10",
                                                            "placeholder"=>"Usuario")); ?>

                                                                                       
        
        <h1> Clinic </h1>
        
    </header>
    
    
    <nav> </nav>
    
    <section>
    
   
        <div id='divFormulario'> 
        <!-- Formulario solicituar cita -->
        <?php echo Form::open(); ?>

        
            <div id='divPrimeraParteForm'>         
            <?php echo Form::label("Nombre"); ?>

            <?php echo Form::input("text", "nombre", "", array("class"=>"form-control")); ?>

            
            <?php echo Form::label("Apellidos"); ?>

            <?php echo Form::input("text", "apellidos","", array("class"=>"form-control")); ?>

            
            <?php echo Form::label("EMAIL"); ?>

            <?php echo Form::input("text", "email","", array("class"=>"form-control")); ?>

            
            <?php echo Form::label("Teléfono"); ?>

            <?php echo Form::input("text", "telefono","", array("class"=>"form-control")); ?>

            </div>
            <div id='divSegundaParteForm'> 
            <?php echo Form::label("Especialidad"); ?>

            <?php echo Form::input("text", "especialidad","", array("class"=>"form-control")); ?>

            
            <?php echo Form::label("Compañia de Seguros"); ?>

            <?php echo Form::input("text", "compañia","", array("class"=>"form-control")); ?>

            
            <?php echo Form::label("Horario"); ?>

            <?php echo Form::input("text", "horario","", array("class"=>"form-control")); ?>

            
            <?php echo Form::label("Motivo de la cita"); ?>

            <?php echo Form::input("text", "motivo","", array("class"=>"form-control")); ?>

            
            <?php echo Form::submit('Solicitar Cita', array("class"=>"btn btn-primary")); ?>

            </div>
        <?php echo Form::close(); ?>

        </div>
        
        
        <div id="divEspecialidades">
            
        </div>
        
        
     </section>
     <footer></footer>

</div>
