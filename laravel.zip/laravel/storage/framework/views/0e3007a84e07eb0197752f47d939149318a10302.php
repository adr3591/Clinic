<!DOCTYPE html>
<html lang="es">
<meta charset='utf-8'>
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1">
    
    				<?php /* Scripts */ ?>
    <?php echo Html::script('assets/js/jquery-2.2.3.js'); ?>

    <?php echo Html::script('assets/js/bootstrap.js'); ?>

    <?php echo Html::script('assets/js/bootstrap-datetimepicker.min.js'); ?>

    <?php echo Html::script('assets/js/script.js'); ?>

    <?php echo Html::script('assets/js/admin.js'); ?>

    
    				<?php /* Styles */ ?>
    <?php echo Html::style('assets/css/principal.css'); ?>

    <?php echo Html::style('assets/css/bootstrap.css'); ?>

    <?php echo Html::style('assets/css/font-awesome.css'); ?>

    <?php echo Html::style('assets/css/w3.css'); ?>

    <?php echo Html::style('assets/css/bootstrap-datetimepicker.min.css'); ?>

    

    <div id='contenedorPrincipal'>
    	
    <header>
    	
    		<div class="row">
    			<div class="col-md-9 col-sm-8 col-xs-6">
   					<h1 id="logoIndice"><?php echo e(HTML::linkAction('ControladorPrincipal@index', 'Clinic', "",array("id"=>"logo"))); ?> </h1>
   				</div>
   			
    		<div class="col-md-3 col-sm-3 col-xs-6">    	
    		<form method="POST" class="form-horizontal" role="form" id="formLogin">
			<?php /* Protección CSRF 'Cross-site request forgeries'*/ ?>
			<?php echo e(csrf_field()); ?>

				<?php /* Si dicho usuario logeado es paciente se habilitara el botón para pedir cita*/ ?>
			<?php if(Auth::check()): ?>
			
				<?php $paciente = DB::table("pacientes")->select("nombre","apellidos")->where('email', Auth::user()->email)->first();?>
					<label class="labelEmailUsuario"> <?php echo $paciente->nombre; echo $paciente->apellidos;         ?> </label> <br>
				
					
					
					<?php if((Auth::user()->tipo_role) == 0): ?>
						<?php echo e(HTML::linkAction('ControladorCitas@pideCita', 'Cita online', array(),array("class"=>"botonCita btn btn-success"))); ?> <br>
   						<?php echo e(HTML::linkAction('ControladorCitas@historial', 'Historial paciente', array(),array("class"=>"botonHistorial btn btn-default"))); ?> <br>

   					<?php endif; ?>
   				
   					
   				<?php /* Si dicho usuario logeado es administrador se habilitara el botón correspondiente a la administracion de la página*/ ?>
   				
   					<?php if((Auth::user()->tipo_role) == 1): ?>
   						<?php echo e(HTML::linkAction('ControladorAdmin@index', 'Administración', array(), array("class"=>"botonAdmin btn btn-warning"))); ?> <br>
   					<?php endif; ?>
   					
   				   
   				<?php echo e(HTML::linkAction('Auth\AuthController@getLogout','Cerrar sesión', array(),array("class"=>"botonCerrarSesion btn btn-danger"))); ?>

   				
   			<?php else: ?>
   				<div style="margin-bottom: 5px" class="input-group">
   				 <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
   				<?php echo Form::text("email", "", array("size"=>"5","placeholder"=>"Email","class"=>"form-control")); ?>

   				 </div> 
            	 <?php if($errors->has('email')): ?>
                       <span class="help-block">
                       		<strong><?php echo e($errors->first('email')); ?></strong>
                       </span>
           		 <?php endif; ?>
           		 
           		 
           		
           		  <div style="margin-bottom: 5px" class="input-group">
                  	<span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>                                             
   					<?php echo Form::password("password",  array("size"=>"10","placeholder"=>"Contraseña", "class"=>"form-control")); ?>

   				  </div>
   				    
              	<?php if($errors->has('password')): ?>
                        <span class="help-block">
                              <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
            	<?php endif; ?>  
            	          
            	
            	                              			
   				<?php echo Form::submit("Acceder", array("class"=>"btn btn-default")); ?>	
   				<?php echo e(HTML::linkAction('ControladorRegistro@index','Registro', array(),array("class"=>"botonRegistro btn btn-primary"))); ?>


				<?php endif; ?>
			</form>
   			
   			</div>	
   			</div>
    </header>

    
	
<?php echo $__env->yieldContent('content'); ?>
</div>