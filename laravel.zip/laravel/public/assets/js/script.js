$(document).ready(function() {
	//Ocultamos una serie de div en la vista citas
	$('#divTramoHorario').hide();
	$('#divCitas').hide();
	$("#loading").hide();
	
	//Index
	$('.panel-body').hide();
	
	$(".panel-heading").click(function() {
  		$(this).siblings().slideToggle( "slow" );
	});
	
	$('.carousel').carousel({
		interval: 4000
	});
	
	
	$('#selectEsp').change(function() {
		$('#divTramoHorario').show();

    });
 
 	$('body').on('click', '.btn-group button', function(e){
 		$(this).addClass("active");
 		$(this).siblings().removeClass("active");
 	});
 
    $('#divTramoHorario').change(function() {
    	 var token = $('#token').val();
    	 var esp = $('#selectEsp').val();
    	 var tramo = $('#tramoHorario').val();
    	 $('#divCitas').show();
    	 $('#loading').show();
    	 $('.col-md-6').remove();
    	 //Peticion asincrona ajax
        $.ajax({
        	//Url para la peticion
        	url: 'peticionFecha',
        	//Información a enviar
        	data: {'especialidadCita' : esp,
        			'tramoHorario': tramo},
        	//Cabecera
        	headers: {'X-CSRF-TOKEN':token},
        	//peticion por post
        	type: 'POST',
        	//json
        	dataType: 'json',
        	//Si la peticion es correcta, la respuesta es pasasda como argumento a la funcion
        	success: function (json){
        		$("#loading").hide();
        		    
					var $cadena = "", i=0, tope=0;
        			for(var item in json){
        				var fecha = new Date(json[item]['fecha']);
        				
        				var $panel = $("<div/>",{"class":"col-md-6"}).append($("<div/>",{
        					"id": "panelFecha-"+json[item]['fecha'],
        					"class":"panelCitas panel panel-primary"
        				}).append($("<div class='panel-heading'><h3 class='panel-title'>"+item+": "+fecha.toLocaleDateString()+"</h3></div>")));
        				
        				var medicos = json[item].medicos;
        				var $select=$("<select/>",{"id":"selectMedico",
        										   "class":"selectMedico form-control"}).append($("<option value='-1'>Selecciona un médico</option>"));
        				
        				var $panelbody = $("<div/>", { "class": "panel-body"});
        				$panelbody.append($select);
        				
        				for (var med in medicos){
        					$select.append($("<option/>",{
        						"id":"option;"+json[item]['fecha']+";"+medicos[med].id,
        						"value": med
        					}).html(medicos[med].nombre));
        					
        					
        					
        					var horas = medicos[med].horas;
        					
        					var $panelhoras = $("<div/>",{"class":"panelhoras col-sm-12 col-md-offset-2 btn-group", "role":"group"});
       							for (var h in horas){
       								$panelhoras.append($("<button type='button' class='btn btn-default'>"+horas[h].substring(0,horas[h].length-3)+"</button>"));
       							}
       							
        					
        						$panelbody.append($panelhoras.hide());
							
						
        				}
        				
        			
       					
       					$panel.find(".panel").eq(0).append($panelbody);
       					$panel.appendTo($("#divCitas div.row").eq(0));
        				
        				$select.change(function() {
							var $this = $(this);
							var med_select = $this.val();
							
							var $panel_horas = $this.siblings("div").eq(med_select);
							$(".panelhoras").hide().find("button").removeClass("active");
							$panel_horas.show();
								
       							
        				});
        				
        			}
        	},
        	//Si la peticion falla
        	error: function(jqXHR, status, error){
        		
        		console.log(error);
        	
        	}
        });
    	 
    });	 
    	 
	$("#btnSolicitaCita").click(function(e){
		e.preventDefault();
		
		var $btn = $("button.active");
		if ($btn.length > 0){
			var hora = $btn.html();
			var datos = $btn.parent().siblings("select").find("option:selected").attr("id").split(";");
			
			var token2 = $('#token2').val();
			var id_paciente = $("#id_paciente").val();
			var id_especialidad = $("#selectEsp").val();
			var id_medico = datos[2];
			var fecha = datos[1];
			var motivo = $("#motivoCita").val();
			
			var data = {
				id_paciente: id_paciente,
				id_medico: id_medico,
				id_especialidad: id_especialidad,
				fecha: fecha,
				hora: hora,
				motivo : motivo
			};
			
			
			$.ajax({
				//Url para la peticion
        		url: 'guardarCita',
				//datos a enviar
				data: data,
				//Cabecera
        		headers: {'X-CSRF-TOKEN':token2},
        		//peticion por post
        		type: 'POST',
        		//json
        		dataType: 'json',
        		//Si la peticion es correcta, la respuesta es pasasda como argumento a la funcion
        		success: function (json){
        			 
        			 var pagina="http://localhost:8888/laravel/public/historial";
					 function redireccionar() {
						location.href=pagina
						
					 } 
        			
        			 setTimeout (redireccionar(), 2000);
        			 
        				
        		},
        		//Si la peticion falla
        		error: function(jqXHR, status, error){
      
        		console.log(error);
        	
        		}
			
			});
		} else {
			alert("Por favor, seleccione una hora concreta antes de solicitar la cita.");
		}
		
		
	
    	
    });
    
   
    
    
    
    
    
    
    
    
    
    
});