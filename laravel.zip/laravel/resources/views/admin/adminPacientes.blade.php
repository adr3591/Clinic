<!-- Heredamos de la plantilla principal -->
@extends('layouts.principal')

@section('content')
	<div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0">
		<h3> Panel administración personal paciente</h3>
	</div>
	
	<div class="divBotones">
		<a href="{{ URL::to('/admin/pacientes') }}"><i class="fa fa-2x fa-refresh"></i></a>
	</div>
	<p> Total de registros: {{ $pacientes->total() }} </p>
	<p> Página {{$pacientes->currentPage() }} de {{ $pacientes->lastPage() }}</p>
	<table class="table table-hover">
		<thead>
			<tr>
			<td><strong>Nombre</strong></td>
			<td><strong>DNI</strong></td>
			<td><strong>Email</strong></td>
			<td><strong>Compañia seguros</strong></td>
			 </tr>
		</thead> 
		<tbody>
			@foreach($pacientes as $paciente)
				<tr class={{ $paciente->id_paciente }}> 
				<td> {{ $paciente->nombre}} {{$paciente->apellidos }} </td>
				<td> {{ $paciente->dni }} </td>
				<td> {{ $paciente->email  }}</td>
				<?php 
				 $c = DB::table("compañiaseguros")->select('nombre')->where('id_compañia',$paciente->id_compañia)->first();
				?>
				<td><?php foreach($c as $s){ echo $c->nombre; } ?></td> </tr>
			@endforeach
		</tbody>
	</table>
	{!! $pacientes->render() !!}
@stop