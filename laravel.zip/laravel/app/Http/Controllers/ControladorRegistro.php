<?php

namespace App\Http\Controllers;

use Auth;
use Session;
use Redirect;
use Validator;
use App\User;
use App\Pacientes;
use App\Compañiaseguros;
use App\Http\Controllers\Controller;
use App\Http\Requests;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;

class ControladorRegistro extends Controller
	{
   
   		public function __construct(){
   			
			
			
   		}

   		 public function index(){
			
    		return view("register");
    }
		 
		 public function registroPaciente(Request $request){
			
			$reglas = [
				'dni' => 'required|size:9|regex:((\d{8})([a-zA-Z]{1}))',											
            	'nombre' => 'required|min:3|max:16|regex:/^[a-záéíóúàèìòùäëïöüñ\s]+$/i',
	            'email' => 'required|email|max:255|unique:users,email',
	            'password' => 'confirmed|required|min:6|max:30',
	            'password_confirmation' => 'required|min:6|max:30',
	            'telefono' => 'required|size:9',
	            'cp' => 'size:5'
				
				
        			];
					
			$mensajes = [
            	'nombre.required' => 'El nombre es requerido',
            	'nombre.min' => 'El mínimo de caracteres permitidos son 3',
            	'nombre.max' => 'El máximo de caracteres permitidos son 16',
           		'nombre.regex' => 'Sólo se aceptan letras',
            	'email.required' => 'El campo es requerido',
            	'email.email' => 'El formato de email es incorrecto',
            	'email.max' => 'El máximo de caracteres permitidos son 255',
            	'email.unique' => 'El email ya existe',
            	'password.required' => 'El campo es requerido',
            	'password.min' => 'El mínimo de caracteres permitidos son 6',
            	'password.max' => 'El máximo de caracteres permitidos son 30',
            	'password.confirmed' =>"La contraseña no coincide",
            	'password_confirmation.required' => 'El campo es requerido',
            	'password_confirmation.min' => 'El mínimo de caracteres permitidos son 6',
            	'password_confirmation.max' => 'El máximo de caracteres permitidos son 18',
            	'dni.required'=>'El DNI es requerido',
            	'dni.size'=>'El formato de dni es incorrecto',
            	'dni.regex'=>'El formato de dni debe ser así 00000000Q',
            	'cp.size'=>'El formato de código postal es incorrecto',
            	'cp.numeric'=>'El formato de código postal es incorrecto',
            	'telefono.required' => 'El número de telefono es requerido',
            	'telefono.numeric'=>'El formato de telefono es incorrecto',
            	'telefono.size' => 'El tamaño del número de telefono es incorrecto'
			];
			
			
			$validator = Validator::make($request->all(), $reglas, $mensajes);
			
			if ($validator->fails()){
            	return redirect("/registro")
            	->withErrors($validator)
            	->withInput();
				
        	}else{
				
				//Instancio el modelo User y registro en la tabla users el email, contraseña y tipo de role de cada paciente
				$usuario = new User;
				$usuario->email = $request->email;
				$usuario->password = bcrypt($request->password);
				$usuario->tipo_role = 0;
				
				//Instancio el modelo y registro en la tabla pacientes todos los datos de cada paciente 
            	$registro = new Pacientes;
            	$registro->nombre = $request->nombre;
            	$registro->email = $request->email;
				$registro->id_compañia = $request->compañia;
	            $registro->password = bcrypt($request->password);
				$registro->dni = $request->dni;
				$registro->apellidos = $request->apellidos;
				$registro->fecha_nacimiento = $request->nacimiento;
				$registro->direccion = $request->direccion;
    	        $registro->codigopostal = $request->cp;
    	        $registro->poblacion = $request->poblacion;
    	        $registro->provincia = $request->provincia;
    	        $registro->telefono = $request->telefono;
			
				//Guardamos los datos recogidos a través de los modelos con la funcion save() que se guardaran
				//en la base de datos
	        	$usuario->save();
            	$registro->save();
            	return redirect("/")
            			->with("mensaje", "Usuario registrado correctamente");
        }

		}		 
}
