<?php /* Heredamos de la plantilla principal */ ?>


<?php $__env->startSection('content'); ?>

<div id='datosRegistro' class='container'>
        		<form method="POST" class="form-horizontal" role="form">
       
        		<?php echo e(csrf_field()); ?>

           		 		<div class="col-md-12 col-md-offset-0 col-sm-12 col-sm-offset-0">
            	        	<h3> Registro médico </h3>
            	        </div>
            	        
            	       		<div class="form-group">
            		  		<?php echo Form::label("nombre","", array("class"=>"control-label col-sm-2")); ?>

            		  		<div class="col-sm-8">
            		  		<?php echo Form::input("text", "nombre", "", array("class"=>"campoRegistro form-control")); ?>

            		  		<div class="text-danger"><?php echo e($errors->first('nombre')); ?></div>
            		  		</div></div>
  						
   						    <div class="form-group">
            				<?php echo Form::label("apellidos","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-8">
            				<?php echo Form::input("text", "apellidos","", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>  

            				<div class="form-group">
							<?php echo Form::label("DNI","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<?php echo Form::input("text", "dni","", array("class"=>"campoRegistro form-control")); ?>

            				<div class="text-danger"><?php echo e($errors->first('dni')); ?></div>
            				</div></div>   	

							<div class="form-group">
            				<?php echo Form::label("especialidad","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-8">
            				<select name="especialidad" class="form-control">
            					<option value="0"> </option>
    							<?php $e = DB::table("especialidades")->get();
								foreach($e as $esp){ 
									?>
								<option value="<?php echo $esp->id_especialidad ?>"> <?php echo $esp->nombre; ?> </option>
								<?php 
									}
								?>
  							</select>
							</div>
            				</div>
            				
            				<div class="form-group">	            			
            				<?php echo Form::label("email","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-8">
            				<?php echo Form::input("email", "email","", array("class"=>"campoRegistro form-control")); ?>

            				<div class="text-danger"><?php echo e($errors->first('email')); ?></div>
            				</div></div>
            				
            				<div class="form-group">
							<?php echo Form::label("direccion","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<?php echo Form::input("text", "direccion","", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>

							<div class="form-group">
							<?php echo Form::label("codigopostal","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<?php echo Form::input("text", "codigopostal","", array("class"=>"campoRegistro form-control")); ?>

            				<div class="text-danger"><?php echo e($errors->first('codigopostal')); ?></div></div></div>

							<div class="form-group">
							<?php echo Form::label("Población","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<?php echo Form::input("text", "poblacion","", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>
							
							<div class="form-group">
							<?php echo Form::label("Provincia","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<?php echo Form::input("text", "provincia","", array("class"=>"campoRegistro form-control")); ?>

							</div></div>
	
							<div class="form-group">
            				<?php echo Form::label("Teléfono","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-8">
            				<?php echo Form::input("text", "telefono","", array("class"=>"campoRegistro form-control")); ?>

							<div class="text-danger"><?php echo e($errors->first('telefono')); ?></div>
							</div></div>

							<div class="form-group">
							<?php echo Form::label("Nº Colegiado","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-8">
            				<?php echo Form::input("text", "colegiado","", array("class"=>"campoRegistro form-control")); ?>

							</div></div>
							
							<div class="form-group">
								<div class="col-sm-offset-5 col-sm-8 col-md-offset-5 col-md-8 col-xs-offset-4 col-xs-8">
            				<?php echo Form::submit("Registrar", array("class"=>"btnRegistro btn btn-primary")); ?>

            				</div></div>
           		</div>
          
        	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>