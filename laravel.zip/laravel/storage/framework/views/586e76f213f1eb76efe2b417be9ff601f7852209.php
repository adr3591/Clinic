<!-- Heredamos de la plantilla principal -->


<?php $__env->startSection('content'); ?>

        		<?php echo Form::open(array("action"=>"../../auth/register",
        							 "method"=>"POST", 
        							 "class"=>"form-horizontal",
        							 "role"=>"form")); ?>

        
           		 <div id='datosRegistro'>
            	        
            	        <h3> Registro </h3>
            	        
            	       		<div class="form-group">
            		  		<?php echo Form::label("Nombre","", array("class"=>"control-label col-sm-2")); ?>

            		  		<div class="col-sm-10">
            		  		<?php echo Form::input("text", "nombre", "", array("class"=>"campoRegistro form-control")); ?>

            		  		</div></div>
  						
   						    <div class="form-group">
            				<?php echo Form::label("Apellidos","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-10">
            				<?php echo Form::input("text", "apellidos","", array("class"=>"campoRegistro form-control")); ?>

            				</div>   </div>     	
            			
							<div class="form-group">	            			
            				<?php echo Form::label("EMAIL","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-10">
            				<?php echo Form::input("text", "email","", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>
						
							<div class="form-group">						
							<?php echo Form::label("Contraseña","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-10">
            				<?php echo Form::input("text", "contraseña","", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>

							<div class="form-group">
							<?php echo Form::label("Contraseña","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-10">
            				<?php echo Form::input("text", "dni","", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>

							<div class="form-group">
							<?php echo Form::label("DNI","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-10">
            				<?php echo Form::input("text", "dni","", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>

							<div class="form-group">
							<?php echo Form::label("Dirección","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-10">
            				<?php echo Form::input("text", "direccion","", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>

							<div class="form-group">
							<?php echo Form::label("Código Postal","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-10">
            				<?php echo Form::input("text", "cp","", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>

							<div class="form-group">
							<?php echo Form::label("Población","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-10">
            				<?php echo Form::input("text", "poblacion","", array("class"=>"campoRegistro form-control")); ?>

            				</div></div>
							
							<div class="form-group">
							<?php echo Form::label("Provincia","", array("class"=>"control-label col-sm-2")); ?>

							<div class="col-sm-10">
            				<?php echo Form::input("text", "provincia","", array("class"=>"campoRegistro form-control")); ?>

							</div></div>
	
							<div class="form-group">
            				<?php echo Form::label("Teléfono","", array("class"=>"control-label col-sm-2")); ?>

            				<div class="col-sm-10">
            				<?php echo Form::input("text", "telefono","", array("class"=>"campoRegistro form-control")); ?>

							</div></div>
							
							<div class="form-group">
								<div class="col-sm-offset-2 col-sm-10">
            				<?php echo Form::submit("Registrarse", array("class"=>"btnRegistro btn btn-primary")); ?>

            				</div></div>
            			
           		</div>
          
        		<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>