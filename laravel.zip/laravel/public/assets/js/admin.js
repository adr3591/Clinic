$(document).ready(function() {
	
	
	//Función que borra un médico
	function borrarMedico(tr){
		
		var id = tr.attr('id');
		console.log(id)
		
	}

});