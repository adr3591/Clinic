<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Compañiaseguros extends Authenticatable
{

	//Variables
	
	/*
	 * En el caso en que nuestra tabla se llame igual que nuestra clase modelo
	 * no haria falta declarar la variable $table
	 * Como no es nuestro caso debemos declararla
	*/
	
	protected $table = "compañiaseguros";
	
	/*
	 * En el caso en que nuestra clave primaria se llamara 'id' no hace falta declararla como varible.
	 * Como no es nuestro caso debemos declararla.
	 */
	 
	protected $primaryKey = "id_compañia";
	
	
	//Añadimos los campos con los que los pacientes van a tratar
	
	protected $fillable = ['nombre','telefono','email'];
	
	
	/* Relaciones */
	
	//Relacion compañiaseguro-pacientes (uno a muchos)
	
	public function pacientes(){
		
		return $this->belongsTo('App\Pacientes');
	}
		
}
	