<?php 

namespace App\Http\Controllers;
use DB;
use App\Citas;
use App\Medicos;
use App\Pacientes;
use Validator;
use App\Compañiaseguros;
use App\Especialidades;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ControladorAdmin extends Controller{

	public function __construct(){
		
		$this->middleware('auth');
	}

	//Acción que muestra la vista principal del panel de administración
	
	public function index(){
		
		return view("admin.admin");
		
	}
	
	
	
	public function citas(){
		
		
		$citas = Citas::paginate(10);
		
		return view("admin.adminCitas",compact('citas'));
		
	}
	
	public function pacientes(){
		
		$pacientes = Pacientes::paginate(10);
				
		return view("admin.adminPacientes", compact('pacientes'));
		
	}
	
	
	public function medicos(){
		
		$medicos = Medicos::paginate(10);
		
		return view("admin.adminMedicos", compact('medicos'));
		
	}
	
	
	public function modificaMedico($id){
		
		return view("admin.modificaMedico", array("id"=>$id));
		
	}
	
	
		public function modificarMedico(Request $request){
		
			$reglas = [
				'dni' => 'required|size:9|regex:((\d{8})([a-zA-Z]{1}))',											
            	'nombre' => 'required|min:3|max:16|regex:/^[a-záéíóúàèìòùäëïöüñ\s]+$/i',
	            'email' => 'required|email|max:255|unique:users,email'
				
				
        			];
					
			$mensajes = [
            	'nombre.required' => 'El nombre es requerido',
            	'nombre.min' => 'El mínimo de caracteres permitidos son 3',
            	'nombre.max' => 'El máximo de caracteres permitidos son 16',
           		'nombre.regex' => 'Sólo se aceptan letras',
            	'email.required' => 'El campo es requerido',
            	'email.email' => 'El formato de email es incorrecto',
            	'email.max' => 'El máximo de caracteres permitidos son 255',
            	'email.unique' => 'El email ya existe',
            	'dni.required'=>'El DNI es requerido',
            	'dni.size'=>'El formato de dni es incorrecto',
            	'dni.regex'=>'El formato de dni debe ser así 00000000Q'
			];
			
			
			$validator = Validator::make($request->all(), $reglas, $mensajes);
			
			if ($validator->fails()){
            	return redirect("/modificaMedico}")
            	->withErrors($validator)
            	->withInput();
				
        	}else{

				$medico = new Medicos();
				$medico->nombre = $request->nombre;
				$medico->apellidos = $request->apellidos;
				$medico->dni = $request->dni;
				$medico->id_especialidad = $request->especialidad;
				$medico->email = $request->email;
				$medico->direccion = $request->direccion;
				$medico->codigopostal = $request->codigopostal;
				$medico->poblacion = $request->poblacion;
				$medico->provincia = $request->provincia;
				$medico->telefono = $request->telefono;
				$medico->n_colegiado = $request->colegiado;
				
				var_dump($request->id);
			
				DB::table("medicos")->where('id_medico',$request->id)->update(array('nombre'=>$request->nombre,
																					'apellidos'=>$request->apellidos,
																					'dni'=>$request->dni,
																					'id_especialidad'=>$request->especialidad,
																					'email'=>$request->email,
																					'direccion'=>$request->direccion,
																					'codigopostal'=>$request->codigopostal,
																					'poblacion'=>$request->poblacion,
																					'provincia'=>$request->provincia,
																					'telefono'=>$request->telefono,
																					'n_colegiado'=>$request->colegiado));
				/**$medico->save();
				
				var_dump($medico);*/
				
				return redirect("/admin/medicos")
            			->with("mensaje", "Usuario registrado correctamente");
			}
		
	}

		public function nuevoMedico(Request $request){
			
			$reglas = [
				'dni' => 'required|size:9|regex:((\d{8})([a-zA-Z]{1}))',											
            	'nombre' => 'required|min:3|max:16|regex:/^[a-záéíóúàèìòùäëïöüñ\s]+$/i',
	            'email' => 'required|email|max:255|unique:users,email'
				
				
        			];
					
			$mensajes = [
            	'nombre.required' => 'El nombre es requerido',
            	'nombre.min' => 'El mínimo de caracteres permitidos son 3',
            	'nombre.max' => 'El máximo de caracteres permitidos son 16',
           		'nombre.regex' => 'Sólo se aceptan letras',
            	'email.required' => 'El campo es requerido',
            	'email.email' => 'El formato de email es incorrecto',
            	'email.max' => 'El máximo de caracteres permitidos son 255',
            	'email.unique' => 'El email ya existe',
            	'dni.required'=>'El DNI es requerido',
            	'dni.size'=>'El formato de dni es incorrecto',
            	'dni.regex'=>'El formato de dni debe ser así 00000000Q'
			];
			
			
			$validator = Validator::make($request->all(), $reglas, $mensajes);
			
			if ($validator->fails()){
            	return redirect("/modificaMedico}")
            	->withErrors($validator)
            	->withInput();
				
        	}else{

				$medico = new Medicos();
				$medico->nombre = $request->nombre;
				$medico->apellidos = $request->apellidos;
				$medico->dni = $request->dni;
				$medico->id_especialidad = $request->especialidad;
				$medico->email = $request->email;
				$medico->direccion = $request->direccion;
				$medico->codigopostal = $request->codigopostal;
				$medico->poblacion = $request->poblacion;
				$medico->provincia = $request->provincia;
				$medico->telefono = $request->telefono;
				$medico->n_colegiado = $request->colegiado;
			
				$medico->save();
				
				return redirect("/admin/medicos");
			}
			
			
		}



		public function borrarMedico(Request $request){
			
			$id = $request->input("id");
			
			DB::table("horario_medico")->where("id_medico",$id)->delete();
			DB::table("citas")->where("id_medico", $id)->delete();
			DB::table("medicos")->where("id_medico", $id)->delete();
			
			return json_encode($id);
		}

}